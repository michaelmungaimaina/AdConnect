export const UserApplicationObject = {
    firstName: "",
    lastName: "",
    emailAddress: "",
    phoneNumber: "",
    occupation: "",
    reason: "",
    goal: "",
    investment: ""
};

export const AppointmentBooking = {
    date: "",
    time: ""
};
export const UserApplicationObject = {
    firstName: "",
    lastName: "",
    emailAddress: "",
    phoneNumber: "",
    occupation: "",
    reason: "",
    goal: "",
    investment: ""
};